// script.js
console.log("Welcome to Valerow!");
